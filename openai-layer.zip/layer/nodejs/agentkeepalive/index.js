'use strict';

module.exports = require('./lib/agent');
module.exports.HttpsAgent = require('./lib/https_agent');
module.exports.constants = require('./lib/constants');
