export * from "../web-runtime.mjs";
//# sourceMappingURL=runtime.mjs.map