/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
import { type Shims } from "./registry.js";
export declare function getRuntime(): Shims;
//# sourceMappingURL=bun-runtime.d.ts.map