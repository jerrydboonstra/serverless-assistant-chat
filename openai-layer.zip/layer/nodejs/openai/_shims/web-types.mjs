/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
