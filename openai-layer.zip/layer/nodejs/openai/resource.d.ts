import type { OpenAI } from "./index.js";
export declare class APIResource {
    protected _client: OpenAI;
    constructor(client: OpenAI);
}
//# sourceMappingURL=resource.d.ts.map