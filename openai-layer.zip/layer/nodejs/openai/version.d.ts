export declare const VERSION = "4.50.0";
//# sourceMappingURL=version.d.ts.map