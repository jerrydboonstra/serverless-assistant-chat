export { Audio } from "./audio.js";
export { SpeechCreateParams, Speech } from "./speech.js";
export { Transcription, TranscriptionCreateParams, Transcriptions } from "./transcriptions.js";
export { Translation, TranslationCreateParams, Translations } from "./translations.js";
//# sourceMappingURL=index.d.ts.map