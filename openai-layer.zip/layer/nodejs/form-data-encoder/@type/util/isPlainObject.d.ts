declare function isPlainObject(value: unknown): value is object;
export default isPlainObject;
