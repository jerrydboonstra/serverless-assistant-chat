import type { Blob, BlobLike } from "./Blob";
export declare type BlobPart = BlobLike | Blob | Uint8Array;
