import { Blob } from "./Blob";
export declare const isBlob: (value: unknown) => value is Blob;
